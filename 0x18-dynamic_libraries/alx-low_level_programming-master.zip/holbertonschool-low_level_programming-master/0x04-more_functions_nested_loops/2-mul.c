#include "holberton.h"

/**
 * mul - multiplies two integers.
 * @a: first number.
 * @b: second number.
 * Return: multiplication.
 */
int mul(int a, int b)
{
	return (a * b);
}
