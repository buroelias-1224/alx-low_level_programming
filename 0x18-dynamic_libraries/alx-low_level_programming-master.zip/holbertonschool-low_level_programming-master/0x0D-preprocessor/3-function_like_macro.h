#ifndef _FUNCTION_LIKE_MACRO_
#define _FUNCTION_LIKE_MACRO_

#define ABS(x) ((x) < (0) ? ((x) * (-1)) : (x))

#endif
