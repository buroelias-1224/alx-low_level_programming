#include <stdio.h>
#define MSG "Hello, Holberton"

/**
 * main - prints a message.
 *
 * Return: Always 0.
 */
int main(void)
{
	printf("%s\n", MSG);
	return (0);
}
